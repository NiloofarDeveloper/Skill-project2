<?php session_start(); ?>
<?php include ('header&footer.php'); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <p id="info">Contact for CEO <hr></p>
    <p id="info">Contact Number: <br><br >  9029890000</p>
</body>
</html>