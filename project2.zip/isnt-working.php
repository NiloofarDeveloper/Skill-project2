<?php session_start(); ?>
<?php include ('header&footer.php'); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <p id="info">So Your Computer Isn't Working</p><hr>
    <img src="images/download.jpg" alt="" width=400px height=400px style="margin:20px">
</body>
</html>