<?php session_start(); ?>
<?php include ('header&footer.php'); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>      


<?php  if ($_SESSION["role1"]){ ?>

<p id="role">Hello Admin</p> <hr>
<p id="options">Here are you options:</p>
<a id="request" href="new-account.php">Create New Account</a> <br><br>
<a id="request" href="isnt-working.php">My computer isn't working</a>    
<?php }; ?>


<?php  if ($_SESSION["role2"]){ ?>

<p id="role">Hello Manager</p> <hr>
<p id="options">Here are you options:</p>
<a id="request" href="lost-password.php">I Lost My Password</a> <br><br>
<a id="request" href="isnt-working.php">My computer isn't working</a>
<?php }; ?> 

<?php  if ($_SESSION["role3"]){ ?>
<p id="role">Hello CEO</p> <hr>
<p id="options">Here are you options:</p>
<a id="request" href="need-help.php">Need Help</a> <br><br>
<a id="request" href="isnt-working.php">My computer isn't working</a>
 
<?php }; ?>   
</body>
</html>